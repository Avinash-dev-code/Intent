package com.example.intent2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.job.JobScheduler;
import android.content.Intent;
import android.hardware.camera2.CameraDevice;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void doSomething(View view) {
        switch (view.getId()){
            case R.id.b1:
                Intent i=new Intent();
                i.setAction(Intent.ACTION_VIEW);
                i.setData(Uri.parse("https://www.google.com"));
                startActivity(i);
            case R.id.b2:
                    Intent i2=new Intent();
                    i2.setAction(Intent.ACTION_CALL);
                    i2.setData(Uri.parse("tel:8828462839"));
                    startActivity(i2);
            case R.id.b3:
                Intent i3=new Intent();
                i3.setAction(MediaStore.ACTION_IMAGE_CAPTURE);

                startActivity(i3);

        }



    }
}
